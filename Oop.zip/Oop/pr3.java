import java.util.Scanner;

public class pr3 {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a value in meters
        System.out.print("Enter a length in meters: ");
        double meters = scanner.nextDouble();

        // Conversion factor: 1 meter = 3.28084 feet
        double feet = meters * 3.28084;

        // Display the result
        System.out.printf("%.2f meters is equal to %.2f feet.%n", meters, feet);

        // Close the scanner
        scanner.close();
    }
}
