class pr2 {
    public static void main(String[] args) {
        // Given coefficients for the equations
        double a = 3.4, b = 50.2, e = 44.5;
        double c = 2.1, d = 0.55, f = 5.9;

        // Calculate the denominator (ad - bc)
        double denominator = (a * d) - (b * c);

        // Check if determinant is zero (no unique solution)
        if (denominator == 0) {
            System.out.println("The equations have no unique solution.");
        } else {
            // Calculate x and y using Cramer's rule
            double x = (e * d - b * f) / denominator;
            double y = (a * f - e * c) / denominator;

            // Display the results
            System.out.printf("Solution: x = %.2f, y = %.2f%n", x, y);
        }
    }
}
