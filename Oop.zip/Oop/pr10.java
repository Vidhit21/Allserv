import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class pr10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // ArrayList to store numbers
        ArrayList<Integer> numbers = new ArrayList<>();

        // Prompt user to enter 10 numbers
        System.out.println("Enter 10 numbers:");
        for (int i = 0; i < 10; i++) {
            numbers.add(scanner.nextInt()); // Add numbers to ArrayList
        }

        // Reverse the ArrayList using Collections.reverse()
        Collections.reverse(numbers);

        // Display reversed numbers
        System.out.println("Reversed numbers:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }

        scanner.close();
    }
}
