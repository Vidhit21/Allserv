import java.util.Random;

public class pr11 {
    public static void main(String[] args) {
        int[][] matrix = new int[6][6];
        Random rand = new Random();

        // Generate and display the matrix
        System.out.println("Generated 6x6 Matrix:");
        for (int i = 0; i < 6; i++) {
            int rowCount = 0; // Count 1s in the row
            for (int j = 0; j < 6; j++) {
                matrix[i][j] = rand.nextInt(2);
                System.out.print(matrix[i][j] + " ");
                if (matrix[i][j] == 1) rowCount++;
            }
            System.out.println(); // Move to next row
            if (rowCount % 2 == 0) { // Ensure odd count
                matrix[i][5] = 1 - matrix[i][5]; // Flip last element
            }
        }

        // Ensure columns have an odd number of 1s
        for (int j = 0; j < 6; j++) {
            int colCount = 0;
            for (int i = 0; i < 6; i++) {
                if (matrix[i][j] == 1) colCount++;
            }
            if (colCount % 2 == 0) { // Ensure odd count
                matrix[5][j] = 1 - matrix[5][j]; // Flip last element
            }
        }

        // Display the corrected matrix
        System.out.println("\nCorrected Matrix (Odd 1s in Rows & Columns):");
        for (int[] row : matrix) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }
    }
}
