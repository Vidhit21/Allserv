import java.util.Random;

public class pr7 {
    public static void main(String[] args) {
        Random random = new Random();

        // Generate three random uppercase letters
        StringBuilder letters = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            char letter = (char) (random.nextInt(26) + 'A'); // Random letter from A-Z
            letters.append(letter);
        }

        // Generate four random digits
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            int digit = random.nextInt(10); // Random digit from 0-9
            digits.append(digit);
        }

        // Combine letters and digits to form a plate number
        String plateNumber = letters.toString() + digits.toString();

        // Display the generated plate number
        System.out.println("Generated Vehicle Plate Number: " + plateNumber);
    }
}
