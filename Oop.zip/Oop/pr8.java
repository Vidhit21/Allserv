import java.util.Scanner;

public class pr8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();

        System.out.print("Smallest factors: ");
        findFactors(number);

        scanner.close();
    }

    // Method to find and print smallest factors
    public static void findFactors(int num) {
        // Start with the smallest prime factor (2)
        while (num % 2 == 0) {
            System.out.print(2 + " ");
            num /= 2;
        }

        // Check for odd factors from 3 onwards
        for (int i = 3; i * i <= num; i += 2) {
            while (num % i == 0) {
                System.out.print(i + " ");
                num /= i;
            }
        }

        // If num is still greater than 1, it's a prime factor itself
        if (num > 1) {
            System.out.print(num);
        }
        
        System.out.println(); // Move to a new line after printing
    }
}
