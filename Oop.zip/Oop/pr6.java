import java.util.Scanner;

public class pr6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user to enter a letter
        System.out.print("Enter a letter: ");
        char letter = scanner.next().toLowerCase().charAt(0); // Convert to lowercase

        // Check if it's a valid alphabet letter
        if (!Character.isLetter(letter)) {
            System.out.println("Invalid input! Please enter an alphabet letter.");
        } else {
            switch (letter) {
                case 'a':
                case 'e':
                case 'i':
                case 'o':
                case 'u':
                    System.out.println(letter + " is a vowel.");
                    break;
                default:
                    System.out.println(letter + " is a consonant.");
            }
        }

        scanner.close();
    }
}
